
/* Includes ------------------------------------------------------------------*/
#include "main.h"

#include "MDR32F9Qx_config.h"
#include "MDR32F9Qx_usb_handlers.h"
#include "MDR32F9Qx_rst_clk.h"
#include "MDR32F9Qx_ssp.h"
#include "MDR32F9Qx_port.h"

#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
//#include <time.h>

/* Private define ------------------------------------------------------------*/
#define BUFFER_LENGTH 128
#define timeout 10
#define FREQ 32000000
//#define DEBUG
#define BufferSize 8

#define LE_XX_Pin PORT_Pin_2
#define LE_XX_Port MDR_PORTF

#define LE_SN_Pin PORT_Pin_3
#define LE_SN_Port MDR_PORTC

#define SPI_RESET_Pin PORT_Pin_4
#define SPI_RESET_Port MDR_PORTC

#define LED_Pin PORT_Pin_2
#define LED_Port MDR_PORTC

/* Configure SSP1 pins: FSS-PF2, CLK-PF1, RXD-PF3, TXD-PF0 */
#define SPI_TX_Pin PORT_Pin_0
#define SPI_CLK_Pin PORT_Pin_1
#define SPI_RX_Pin PORT_Pin_3
#define SPI_Port MDR_PORTF

/* GPIO definition -----------------------------------------------------------*/

#define SDR_GPIO //Если микроконтроллер используется в радиотракте SDR, раскомментируйте эту строку
//#define GPIO_DEBUG // Если включено, в консоль будут выводиться значения на пинах, отвечающих за GPIO интерфейс


#ifdef SDR_GPIO
	#define GPIO_RX_0 PORT_Pin_5
	#define GPIO_RX_1 PORT_Pin_1
	#define GPIO_RX_2 PORT_Pin_4
	#define GPIO_RX_3 PORT_Pin_3
	#define GPIO_RX_4 PORT_Pin_0
	#define GPIO_RX_5 PORT_Pin_2
	#define GPIO_RX_Port MDR_PORTA


	#define GPIO_TX_0 PORT_Pin_6
	#define GPIO_TX_1 PORT_Pin_7
	#define GPIO_TX_2 PORT_Pin_0
	#define GPIO_TX_3 PORT_Pin_1
	#define GPIO_TX_4 PORT_Pin_10
	#define GPIO_TX_5 PORT_Pin_9
	
	#define GPIO_TX_Port1 MDR_PORTA
	#define GPIO_TX_Port2 MDR_PORTC
	#define GPIO_TX_Port3 MDR_PORTB
#endif

#ifndef SDR_GPIO
	#define GPIO_Pin_0 PORT_Pin_0
	#define GPIO_Pin_1 PORT_Pin_1
	#define GPIO_Pin_2 PORT_Pin_2
	#define GPIO_Pin_3 PORT_Pin_3
	#define GPIO_Pin_4 PORT_Pin_4
	#define GPIO_Pin_5 PORT_Pin_5
	#define GPIO_Port MDR_PORTA
#endif


/* Private variables ---------------------------------------------------------*/
static USB_Clock_TypeDef USB_Clock_InitStruct;
static USB_DeviceBUSParam_TypeDef USB_DeviceBUSParam;
static MDR_SSP_TypeDef SSP_InitStruct;
SSP_InitTypeDef sSSP;
PORT_InitTypeDef PORT_InitStructure;


static uint8_t Buffer[BUFFER_LENGTH];
//static uint8_t RecBuf[BUFFER_LENGTH];
//static uint8_t DoubleBuf[BUFFER_LENGTH * 2];

#define HL_RX_BUFFER_SIZE 256 // Can be larger if desired
uint8_t rxBuffer[HL_RX_BUFFER_SIZE]; // Receive buffer
volatile uint16_t rxBufferHeadPos = 0; // Receive buffer write position
volatile uint16_t rxBufferTailPos = 0; // Receive buffer read position
  // Read buffer
uint8_t rxData[HL_RX_BUFFER_SIZE];
uint8_t stringBuffer[HL_RX_BUFFER_SIZE];


typedef enum
{
  USB_CDC_RX_BUFFER_OK   = 0U,
  USB_CDC_RX_BUFFER_NO_DATA
} USB_CDC_RX_BUFFER_StatusTypeDef;


char *start;
char *end;
char tokens[5][BUFFER_LENGTH * 2]; //usb parsing tokens pointers array
char tempString[100];			   //debug

uint16_t SPI_TX_Buf[BufferSize];
uint16_t SPI_RX_Buf[BufferSize];

//uint32_t RecLen = 0;//usb data len

#ifdef USB_CDC_LINE_CODING_SUPPORTED
static USB_CDC_LineCoding_TypeDef LineCoding;
#endif /* USB_CDC_LINE_CODING_SUPPORTED */

/* Private function prototypes -----------------------------------------------*/
static void Setup_CPU_Clock(void);
static void Setup_SPI(void);
static void Setup_USB(void);
static void Setup_GPIO(void);
static void VCom_Configuration(void);
static void USB_PrintDebug(char *format, ...);
uint16_t USB_CDC_GetRxBufferBytesAvailable_FS();
uint8_t USB_CDC_ReadRxBuffer_FS(uint8_t* Buf, uint16_t Len);
void USB_CDC_FlushRxBuffer_FS();

/* Private functions ---------------------------------------------------------*/
void delayTick(uint32_t count)
{

	while (count--)
		;
}

void delay(int milliseconds)
{
    long pause;
//    clock_t now,then;

    pause = milliseconds*(FREQ/1000);
//    now = then = clock();
    while(pause>0 )
        pause--;
}

void USB_Print(char *format, ...)
{
	va_list argptr;
	va_start(argptr, format);

	vsprintf(tempString, format, argptr);
	va_end(argptr);
	USB_CDC_SendData((uint8_t *)tempString, strlen(tempString));
	delayTick(timeout);
}

void SPI_Send_Bytes(uint8_t bytes)
{

	for (uint8_t j = 0; j < bytes; j++)
	{
		//check if internal SPI buffer is full
		while (SSP_GetFlagStatus(MDR_SSP1, SSP_FLAG_TNF) == RESET)
		{
		} //while (SSP_GetFlagStatus(MDR_SSP1, SSP_FLAG_TFE) == RESET)

		SSP_SendData(MDR_SSP1, SPI_TX_Buf[j]);
	}

	//wait for SPI not busy
	while (SSP_GetFlagStatus(MDR_SSP1, SSP_FLAG_BSY) == SET)
	{
	}
}
void SPI_SendRead_Bytes(uint8_t bytes)
{

	for (uint8_t j = 0; j < bytes; j++)
	{
		//check FIFO buffer is empty
		while (SSP_GetFlagStatus(MDR_SSP1, SSP_FLAG_TFE) == RESET)
		{
		}
		SSP_SendData(MDR_SSP1, SPI_TX_Buf[j]);

		//check if SPI busy
		while (SSP_GetFlagStatus(MDR_SSP1, SSP_FLAG_BSY) == SET)
		{
		}
		SPI_RX_Buf[j] = SSP_ReceiveData(MDR_SSP1);
	}

	//wait for SPI not busy
	while (SSP_GetFlagStatus(MDR_SSP1, SSP_FLAG_BSY) == SET)
	{
	}
}

void SPI_Send(char *mes, MDR_PORT_TypeDef *MDR_LE_PORT, uint32_t MDR_LE_PIN)
{
	uint16_t bytes = strlen(mes) / 2;
	uint16_t nextData;
	char HexBuffer[2] = {0};
	for (uint8_t j = 0; j < bytes; j++)
	{
		strncpy(HexBuffer, mes + j * 2, 2);
		USB_PrintDebug("%s\n", HexBuffer);
		sscanf(HexBuffer, "%hx", &nextData);
		SPI_TX_Buf[j] = nextData;
	}

	PORT_ResetBits(MDR_LE_PORT, MDR_LE_PIN);
	SPI_Send_Bytes(bytes);
	PORT_SetBits(MDR_LE_PORT, MDR_LE_PIN);
}

void SPI_SendRead(char *mes, MDR_PORT_TypeDef *MDR_LE_PORT, uint32_t MDR_LE_PIN)
{
	uint16_t bytes = strlen(mes) / 2;
	uint16_t nextData;
	char HexBuffer[2] = {0};
	for (uint8_t j = 0; j < bytes; j++)
	{
		strncpy(HexBuffer, mes + j * 2, 2);
		USB_PrintDebug("%s\n", HexBuffer);
		sscanf(HexBuffer, "%hx", &nextData);
		SPI_TX_Buf[j] = nextData;
	}

	PORT_ResetBits(MDR_LE_PORT, MDR_LE_PIN);
	SPI_SendRead_Bytes(bytes);
	PORT_SetBits(MDR_LE_PORT, MDR_LE_PIN);
}

void SPI_SendThenRead(char *mes, uint8_t bytesToRead, MDR_PORT_TypeDef *MDR_LE_PORT, uint32_t MDR_LE_PIN)
{
	uint16_t bytes = strlen(mes) / 2;
	uint16_t nextData;
	char HexBuffer[2] = {0};
	for (uint8_t j = 0; j < bytes; j++)
	{
		strncpy(HexBuffer, mes + j * 2, 2);
		USB_PrintDebug("%s\n", HexBuffer);
		sscanf(HexBuffer, "%hx", &nextData);
		SPI_TX_Buf[j] = nextData;
	}

	PORT_ResetBits(MDR_LE_PORT, MDR_LE_PIN);
	//SPI_Send_Bytes(bytes);
	SPI_SendRead_Bytes(bytes);
	SPI_SendRead_Bytes(bytesToRead);
	PORT_SetBits(MDR_LE_PORT, MDR_LE_PIN);
}




// СКУДОУМНЫЙ КОД ДАЛЕЕ

#ifdef SDR_GPIO
void GPIO_RX_Set (char *chunk)
	{
		uint16_t value;
		sscanf(chunk, "%hx", &value);
		
		
		PORT_WriteBit (GPIO_RX_Port, GPIO_RX_0, ((value >> 0) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_RX_Port, GPIO_RX_1, ((value >> 1) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_RX_Port, GPIO_RX_2, ((value >> 2) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_RX_Port, GPIO_RX_3, ((value >> 3) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_RX_Port, GPIO_RX_4, ((value >> 4) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_RX_Port, GPIO_RX_5, ((value >> 5) & 1u)?Bit_SET:Bit_RESET);
		
		#ifdef GPIO_DEBUG
		uint8_t port_value = PORT_ReadInputDataBit (GPIO_RX_Port, GPIO_RX_0) | 
		PORT_ReadInputDataBit (GPIO_RX_Port, GPIO_RX_1)<<1 |
		PORT_ReadInputDataBit (GPIO_RX_Port, GPIO_RX_2)<<2 |
		PORT_ReadInputDataBit (GPIO_RX_Port, GPIO_RX_3)<<3 |
		PORT_ReadInputDataBit (GPIO_RX_Port, GPIO_RX_4)<<4 |
		PORT_ReadInputDataBit (GPIO_RX_Port, GPIO_RX_5)<<5;
		
		USB_Print ("current RX port value is %x\n", port_value);
		#endif
	}
	
void GPIO_TX_Set (char *chunk)
	{
		uint16_t value;
		sscanf(chunk, "%hx", &value);
		
		PORT_WriteBit (GPIO_TX_Port3, GPIO_TX_5, ((value >> 0) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port1, GPIO_TX_1, ((value >> 1) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port3, GPIO_TX_4, ((value >> 2) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port2, GPIO_TX_3, ((value >> 3) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port1, GPIO_TX_0, ((value >> 4) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port2, GPIO_TX_2, ((value >> 5) & 1u)?Bit_SET:Bit_RESET);
		
		/*
		PORT_WriteBit (GPIO_TX_Port1, GPIO_TX_0, ((value >> 0) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port2, GPIO_TX_2, ((value >> 1) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port2, GPIO_TX_3, ((value >> 2) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port3, GPIO_TX_5, ((value >> 3) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port1, GPIO_TX_1, ((value >> 4) & 1u)?Bit_SET:Bit_RESET);
		PORT_WriteBit (GPIO_TX_Port3, GPIO_TX_4, ((value >> 5) & 1u)?Bit_SET:Bit_RESET);
		*/
		#ifdef GPIO_DEBUG
		uint8_t port_value = PORT_ReadInputDataBit (GPIO_TX_Port1, GPIO_TX_0) | 
		PORT_ReadInputDataBit (GPIO_TX_Port1, GPIO_TX_1)<<1 |
		PORT_ReadInputDataBit (GPIO_TX_Port2, GPIO_TX_2)<<2 |
		PORT_ReadInputDataBit (GPIO_TX_Port2, GPIO_TX_3)<<3 |
		PORT_ReadInputDataBit (GPIO_TX_Port3, GPIO_TX_4)<<4 |
		PORT_ReadInputDataBit (GPIO_TX_Port3, GPIO_TX_5)<<5;
		
		USB_Print ("current TX port value is %x\n", port_value);
		#endif
	}
	#endif
	#ifndef SDR_GPIO
void GPIO_Set (char *chunk)
{
	uint16_t value;
	USB_Print ("current port value is %x\n", PORT_ReadInputData(GPIO_Port));
	sscanf(chunk, "%hx", &value);
	USB_Print ("passed number is %hx\n", value);
	USB_Print ("bit representation: %hx %hx %hx %hx %hx %hx\n", (value >> 5) & 1u, (value >> 4) & 1u, (value >> 3) & 1u, (value >> 2) & 1u, (value >> 1) & 1u, (value >> 0) & 1u);
	
	
	PORT_WriteBit (GPIO_Port, GPIO_Pin_0, ((value >> 0) & 1u)?Bit_SET:Bit_RESET);
	PORT_WriteBit (GPIO_Port, GPIO_Pin_1, ((value >> 1) & 1u)?Bit_SET:Bit_RESET);
	PORT_WriteBit (GPIO_Port, GPIO_Pin_2, ((value >> 2) & 1u)?Bit_SET:Bit_RESET);
	PORT_WriteBit (GPIO_Port, GPIO_Pin_3, ((value >> 3) & 1u)?Bit_SET:Bit_RESET);
	PORT_WriteBit (GPIO_Port, GPIO_Pin_4, ((value >> 4) & 1u)?Bit_SET:Bit_RESET);
	PORT_WriteBit (GPIO_Port, GPIO_Pin_5, ((value >> 5) & 1u)?Bit_SET:Bit_RESET);
	
	#ifdef GPIO_DEBUG
	uint8_t port_value = PORT_ReadInputDataBit (GPIO_Port, GPIO_Pin_0) | 
		PORT_ReadInputDataBit (GPIO_Port, GPIO_Pin_1)<<1 | 
		PORT_ReadInputDataBit (GPIO_Port, GPIO_Pin_2)<<2 | 
		PORT_ReadInputDataBit (GPIO_Port, GPIO_Pin_3)<<3 | 
		PORT_ReadInputDataBit (GPIO_Port, GPIO_Pin_4)<<4 | 
		PORT_ReadInputDataBit (GPIO_Port, GPIO_Pin_5)<<5;
	
	USB_Print ("current port value bytewise is %x\n", port_value);
	// USB_Print ("current port value is %x\n", PORT_ReadInputData(GPIO_Port));
	#endif
}
	
	#endif
// СКУДОУМНЫЙ КОД КОНЕЦ

void USB_PrintDebug(char *format, ...)
{
#ifdef DEBUG
	va_list argptr;
	va_start(argptr, format);

	vsprintf(tempString, format, argptr);
	va_end(argptr);
	//CDC_Transmit_FS((uint8_t *)tempString,strlen(tempString) );
	USB_CDC_SendData((uint8_t *)tempString, strlen(tempString));
	delayTick(timeout);
#endif
}

void ResetRXTX()
{
	PORT_SetBits(SPI_RESET_Port, SPI_RESET_Pin);   //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_SET);
	PORT_ResetBits(SPI_RESET_Port, SPI_RESET_Pin); //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET); //inversed reset

	PORT_ResetBits (MDR_PORTA, PORT_Pin_All);
	PORT_InitStructure.PORT_Pin = (SPI_CLK_Pin);   //GPIO_InitStruct.Pin = GPIO_PIN_5;
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT; //GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	PORT_Init(SPI_Port, &PORT_InitStructure);	   //HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	//PORT_ResetBits(SPI_Port, SPI_CLK_Pin);

	PORT_SetBits(SPI_Port, SPI_CLK_Pin); //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
	delayTick(100);
	PORT_ResetBits(SPI_Port, SPI_CLK_Pin); //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

	PORT_InitStructure.PORT_FUNC = PORT_FUNC_ALTER; //GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	PORT_Init(SPI_Port, &PORT_InitStructure);		//HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	PORT_ResetBits(SPI_RESET_Port, SPI_RESET_Pin); //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_RESET);
	PORT_SetBits(SPI_RESET_Port, SPI_RESET_Pin);   //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET); //inversed reset
}

void LEDBlink(){
	PORT_SetBits(LED_Port, LED_Pin);
	delay(1000);
	PORT_ResetBits(LED_Port, LED_Pin); 
delay(1000);
}

void USB_Print_SPI_Buffers(char *prefix, uint8_t bytes)
{
	strcpy(tempString, prefix);
	char temp[10];

	for (uint8_t i = 0; i < bytes; i++)
	{
		sprintf(temp, "%02X", SPI_TX_Buf[i]);
		strcat(tempString, temp);
	}
	strcat(tempString, " ");
	for (uint8_t i = 0; i < bytes; i++)
	{
		sprintf(temp, "%02X", SPI_RX_Buf[i]);
		strcat(tempString, temp);
	}
	strcat(tempString, "\n");

	USB_Print(tempString);
}

static void Parse(uint8_t *str)
{
	char *rest = (char *)str;
	const char k[2] = ",";
	char *chunk = strtok((char *)str, k); //find first token
	//char* chunk = strtok_r((char*)str,",",&rest);//find first token

	uint8_t num = 0; //tokens quantity

	while (chunk != NULL)
	{
		strcpy(tokens[num], chunk); //copy chunk as token
		num++;						//increase tokens counter
		//chunk = strtok_r(NULL,",",&rest);//find next token
		chunk = strtok(NULL, k); //find next token
	}

	for (uint8_t i = 0; i < num; i++)
	{
		uint8_t counter = 0;

		chunk = strtok(tokens[i], ".");
		switch (chunk[0])
		{
		case 'n':
			USB_Print("SPI\n");
			break;
		case 's':
			ResetRXTX();
		case 'f': //24-bit PLL
		case 'u': //Universal
			while (chunk != NULL)
			{
				if (counter != 0)
				{
					USB_PrintDebug("%s\n", chunk);
					SPI_SendRead(chunk, LE_XX_Port, LE_XX_Pin);
				}
				counter++;
				chunk = strtok(NULL, ".");
			}
			break;
			
			// СКУДОУМНЫЙ КОД ДАЛЕЕ
			

		
		
			
		#ifndef SDR_GPIO	
		case 'g': //Универсальное управление интерфейса GPIO для разъема GPIO 0 
			  
				chunk = strtok(NULL, ".");
				GPIO_Set (chunk);
				break;
				
		#endif
		#ifdef SDR_GPIO
		
		case 'g': //Управление GPIO для настройки усилителей мощности в SDR 
			// Формат запроса: <g.X.YY>, где X - контрольный байт, определяющий усилитель, а YY - передаваемое 6-битное значение в шестнадцатеричном формате
			chunk = strtok(NULL, ".");
		if (*chunk == '0') // Если контрольный байт равен нулю, идет настройка GPIO интерфейса для разъема GPIO 0, в SDR это усилитель RX
			{
				chunk = strtok(NULL, ".");
				GPIO_RX_Set(chunk);
			}
			else // Если контрольный байт равен любому другому числу, идет настройка GPIO интерфейса для разъема I2C, в SDR это усилитель TX
			{
				chunk = strtok(NULL, ".");
				GPIO_TX_Set(chunk);
			}
			break;
		#endif
		
		case 'h':
		
			USB_Print ("<h> - Outputs possible commands into a console \n"); delayTick (100);
			USB_Print ("<n> - Output the \"SPI\" message in console, for debug\n"); delayTick (100);
			USB_Print ("<g.XX> - GPIO interface control, where XX is a hexadecimal number ranging from 00 to 3F\n");delayTick (100);
			USB_Print ("<s>, <S> - Reset the SPI value\n");delayTick (100);
			USB_Print ("<f> - 24-bit PLL \n");delayTick (100);
			USB_Print ("<u.value1.value2...> - Universal SPI interface control \n");delayTick (100);
			USB_Print ("   Quantity and sizes of values may vary\n");delayTick (100);
			USB_Print ("<U.value1.value2...> - Universal SPI interface control \n");delayTick (100);
			USB_Print ("   Quantity and sizes of values may vary\n");delayTick (100);
			USB_Print ("   After writing the values they are read for debug\n");delayTick (100);
			USB_Print ("<z> - Synth 089 48 bits\n");delayTick (100);
			USB_Print ("<y> - Synth mldr 32 bits \n");delayTick (100);
			USB_Print ("<Y> - Synth mldr 32 READ \n");delayTick (100);
			
			break;
		
			
			// СКУДОУМНЫЙ КОД КОНЕЦ
			
		case 'S': //SPI 32 bits with reset READ
			ResetRXTX();
		case 'U':
			while (chunk != NULL)
			{
				if (counter != 0)
				{
					USB_PrintDebug("%s\n", chunk);
					SPI_SendThenRead(chunk, 4, LE_XX_Port, LE_XX_Pin);
					USB_Print_SPI_Buffers("LE_XX ", 4);
				}
				counter++;
				chunk = strtok(NULL, ".");
			}
			break;
		case 'z': //Synth 089 48 bits
		case 'y': //Synth mldr 32 bits
			while (chunk != NULL)
			{
				if (counter != 0)
				{
					USB_PrintDebug("%s\n", chunk);
					SPI_Send(chunk, LE_SN_Port, LE_SN_Pin);
				}
				counter++;
				chunk = strtok(NULL, ".");
			}
			break;
		case 'Y': //Synth mldr 32 READ
			while (chunk != NULL)
			{
				if (counter != 0)
				{
					USB_PrintDebug("%s\n", chunk);
					SPI_SendThenRead(chunk, 4, LE_SN_Port, LE_SN_Pin);
					USB_Print_SPI_Buffers("SN ", 4);
				}
				counter++;
				chunk = strtok(NULL, ".");
			}
			break;
		default:
			USB_PrintDebug("Unknown cmd: %s\n", tokens[i]);
			break;
		}
	}

	//LEDBlink();
	
	//PORT_WriteBit(LED_Port,LED_Pin,PORT_ReadInputDataBit(LED_Port,LED_Pin)?Bit_SET:Bit_RESET);
	//USB_Print("ok\n");
}

/**
	* @brief	Main program - initialization and empty infinite loop
	* @param	None
	* @retval None
	*/
int main(void)
{
	VCom_Configuration();

	/* CDC layer initialization */
	USB_CDC_Init(Buffer, 1, SET);

	Setup_CPU_Clock();
	Setup_USB();
	Setup_SPI();
	Setup_GPIO();
	
	


	/* Main loop */
	while (1)
	{
    uint16_t bytesAvailable = USB_CDC_GetRxBufferBytesAvailable_FS();
    if (bytesAvailable > 0) {
		if (USB_CDC_ReadRxBuffer_FS(rxData, bytesAvailable) == USB_CDC_RX_BUFFER_OK){
			if(strlen((char *)stringBuffer)+ strlen((char *)rxData) > 256 ) memset(stringBuffer, 0, HL_RX_BUFFER_SIZE);
			strcat((char *)stringBuffer, (char *)rxData);
			memset(rxData, 0, HL_RX_BUFFER_SIZE);
			start = strchr((char *)stringBuffer, '<');
			end = strchr((char *)stringBuffer, '>');
			if (end != NULL && start != NULL && end > start)
			{
				*end = '\0'; //delete last >
				
				Parse((uint8_t *)start + 1); //+1 for deleting first <
				//USB_CDC_SendData(DoubleBuf, strlen((char*)DoubleBuf));
				//USB_CDC_FlushRxBuffer_FS();
				memset(stringBuffer, 0, HL_RX_BUFFER_SIZE);
			}
		}
		
		}

		}
	}
	
//	while (1)
//	{
//			//LEDBlink();
//		if (RecBuf[0] != 0)
//		{
//			if (strlen((char *)DoubleBuf) < 256 - 64)
//			{ //combining strings
//				strcat((char *)DoubleBuf, (char *)RecBuf);
//			}
//			else
//			{
//				memset(DoubleBuf, 0, 256);
//				strcat((char *)DoubleBuf, (char *)RecBuf);
//			}
//			memset(RecBuf, 0, 128);
//			start = strchr((char *)DoubleBuf, '<');
//			end = strchr((char *)DoubleBuf, '>');
//			if (end != NULL && start != NULL && end > start)
//			{
//				*end = '\0'; //delete last >
//				//*++end='\0';
//				Parse((uint8_t *)start + 1); //+1 for deleting first <
//				//USB_CDC_SendData(DoubleBuf, strlen((char*)DoubleBuf));
//				memset(DoubleBuf, 0, 256);
//			}
//			else if (end != NULL)
//			{
//				memset(DoubleBuf, 0, 256);
//				//Send("DB: %s",DoubleBuf);
//			}
//		}
//	}



// СКУДОУМНЫЙ КОД ДАЛЕЕ

void Setup_GPIO(void)
{
	#ifdef SDR_GPIO
	
	RST_CLK_PCLKcmd((RST_CLK_PCLK_PORTA | RST_CLK_PCLK_PORTC | RST_CLK_PCLK_PORTB), ENABLE);
	
	PORT_InitStructure.PORT_Pin = (GPIO_RX_0) | (GPIO_RX_1) | (GPIO_RX_2) | (GPIO_RX_3) | (GPIO_RX_4) | (GPIO_RX_5);
	PORT_InitStructure.PORT_OE = PORT_OE_OUT;
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
	PORT_InitStructure.PORT_PD = PORT_PD_DRIVER;
	PORT_Init(GPIO_RX_Port, &PORT_InitStructure);
	
	PORT_InitStructure.PORT_Pin = (GPIO_TX_0) | (GPIO_TX_1);
	PORT_InitStructure.PORT_OE = PORT_OE_OUT;
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
	PORT_InitStructure.PORT_PD = PORT_PD_DRIVER;
	PORT_Init(GPIO_TX_Port1, &PORT_InitStructure);

	PORT_InitStructure.PORT_Pin = (GPIO_TX_2) | (GPIO_TX_3);
	PORT_InitStructure.PORT_OE = PORT_OE_OUT;
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
	PORT_InitStructure.PORT_PD = PORT_PD_DRIVER;
	PORT_Init(GPIO_TX_Port2, &PORT_InitStructure);

	PORT_InitStructure.PORT_Pin = (GPIO_TX_4) | (GPIO_TX_5);
	PORT_InitStructure.PORT_OE = PORT_OE_OUT;
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
	PORT_InitStructure.PORT_PD = PORT_PD_DRIVER;
	PORT_Init(GPIO_TX_Port3, &PORT_InitStructure);	
	
	#endif
	
	#ifndef SDR_GPIO
	
	RST_CLK_PCLKcmd((RST_CLK_PCLK_PORTA), ENABLE);
	

	PORT_InitStructure.PORT_Pin = (GPIO_Pin_0) | (GPIO_Pin_1) | (GPIO_Pin_2) | (GPIO_Pin_3) | (GPIO_Pin_4) | (GPIO_Pin_5);
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
	PORT_InitStructure.PORT_OE = PORT_OE_OUT;
	PORT_InitStructure.PORT_PD = PORT_PD_DRIVER;
	PORT_Init(GPIO_Port, &PORT_InitStructure);
	
	/*
	PORT_InitStructure.PORT_Pin = (PORT_Pin_All);
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
	PORT_InitStructure.PORT_OE = PORT_OE_OUT;
	PORT_InitStructure.PORT_PD = PORT_PD_DRIVER;
	PORT_Init(MDR_PORTA, &PORT_InitStructure);
	PORT_ResetBits (MDR_PORTA, PORT_Pin_All);
	*/
	#endif
}

// СКУДОУМНЫЙ КОД КОНЕЦ



void Setup_SPI(void)
{
	/* Enable peripheral clocks --------------------------------------------------*/
	RST_CLK_PCLKcmd((RST_CLK_PCLK_RST_CLK | RST_CLK_PCLK_SSP1 | RST_CLK_PCLK_SSP2), ENABLE);
	RST_CLK_PCLKcmd((RST_CLK_PCLK_PORTF | RST_CLK_PCLK_PORTD | RST_CLK_PCLK_PORTC), ENABLE);

	/* Configure SSP1 pins: FSS-PF2, CLK-PF1, RXD-PF3, TXD-PF0 */

	/* Configure PORTF pins 0, 1, 2, 3 */
	PORT_InitStructure.PORT_Pin = (SPI_RX_Pin);
	PORT_InitStructure.PORT_OE = PORT_OE_IN;
	PORT_InitStructure.PORT_FUNC = PORT_FUNC_ALTER;
	PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
	PORT_InitStructure.PORT_SPEED = PORT_SPEED_MAXFAST;
	PORT_Init(SPI_Port, &PORT_InitStructure);
	PORT_InitStructure.PORT_Pin = (SPI_CLK_Pin); //(PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2);
	PORT_InitStructure.PORT_OE = PORT_OE_OUT;
	PORT_Init(SPI_Port, &PORT_InitStructure);
	PORT_InitStructure.PORT_Pin = (SPI_TX_Pin); //(PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2);
	PORT_InitStructure.PORT_PULL_DOWN = PORT_PULL_DOWN_ON;
	PORT_Init(SPI_Port, &PORT_InitStructure);
	

	PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
	PORT_InitStructure.PORT_Pin = (LE_XX_Pin);
	PORT_Init(LE_XX_Port, &PORT_InitStructure);
	PORT_SetBits(LE_XX_Port, LE_XX_Pin);

	PORT_InitStructure.PORT_Pin = (LE_SN_Pin);
	PORT_Init(LE_SN_Port, &PORT_InitStructure);
	PORT_SetBits(LE_SN_Port, LE_SN_Pin);

	PORT_InitStructure.PORT_Pin = (SPI_RESET_Pin);
	PORT_Init(SPI_RESET_Port, &PORT_InitStructure);
	PORT_SetBits(SPI_RESET_Port, SPI_RESET_Pin);
	
	//PORT_InitStructure.PORT_Pin = (LED_Pin);
	//PORT_Init(LED_Port, &PORT_InitStructure);
	//PORT_SetBits(LED_Port, LED_Pin);
	

	/* Initializes the SSPx peripheral clock according to the specified parameters ------------------------------------------------*/
	SSP_BRGInit(MDR_SSP1, SSP_HCLKdiv16);

	/* SSP1 MASTER configuration ------------------------------------------------*/
	SSP_StructInit(&sSSP);

	/*F_SSPCLK / ( CPSDVR * (1 + SCR) ) 
	  32 / (2*(1+15)) = 1 MHZ
	
	*/

	sSSP.SSP_SCR = 0x0F; //15
	sSSP.SSP_CPSDVSR = 2;
	sSSP.SSP_Mode = SSP_ModeMaster;
	sSSP.SSP_WordLength = SSP_WordLength8b;
	sSSP.SSP_SPH = SSP_SPH_1Edge;
	sSSP.SSP_SPO = SSP_SPO_Low;
	sSSP.SSP_FRF = SSP_FRF_SPI_Motorola;
	sSSP.SSP_HardwareFlowControl = SSP_HardwareFlowControl_None;
	//sSSP.SSP_HardwareFlowControl = SSP_HardwareFlowControl_SSE;
	SSP_Init(MDR_SSP1, &sSSP);

	/* Enable SSP1 */
	SSP_Cmd(MDR_SSP1, ENABLE);
}

/**
	* @brief	Frequencies setup
	* @param	None
	* @retval None
	*/
void Setup_CPU_Clock(void)
{
	/* Enable HSE */
	RST_CLK_HSEconfig(RST_CLK_HSE_ON);
	if (RST_CLK_HSEstatus() != SUCCESS)
	{
	/* Trap */
	while (1)
	{
	}
	}

	/* CPU_C1_SEL = HSE/2 */
	//RST_CLK_CPU_PLLconfig(RST_CLK_CPU_PLLsrcHSEdiv2, RST_CLK_CPU_PLLmul10);
	/* CPU_C1_SEL = HSI */
	//RST_CLK_CPU_PLLconfig(RST_CLK_CPU_PLLsrcHSIdiv1, RST_CLK_CPU_PLLmul4); //8*4 32 MHz
	RST_CLK_CPU_PLLconfig(RST_CLK_CPU_PLLsrcHSEdiv2, RST_CLK_CPU_PLLmul4); //16/2*4 32 MHz
	
	RST_CLK_CPU_PLLcmd(ENABLE);
	if (RST_CLK_CPU_PLLstatus() != SUCCESS)
	{
		/* Trap */
		while (1)
		{
		}
	}

	/* CPU_C3_SEL = CPU_C2_SEL */
	RST_CLK_CPUclkPrescaler(RST_CLK_CPUclkDIV1);
	/* CPU_C2_SEL = PLL */
	RST_CLK_CPU_PLLuse(ENABLE);
	/* HCLK_SEL = CPU_C3_SEL */
	RST_CLK_CPUclkSelection(RST_CLK_CPUclkCPU_C3);
}

/**
	* @brief	USB Device layer setup and powering on
	* @param	None
	* @retval None
	*/
void Setup_USB(void)
{
	/* Enables the CPU_CLK clock on USB */
	RST_CLK_PCLKcmd(RST_CLK_PCLK_USB, ENABLE);

	/* Device layer initialization */
	//USB_Clock_InitStruct.USB_USBC1_Source = USB_C1HSIdiv1; //HSE not working :( using HSI 8Mhz
	USB_Clock_InitStruct.USB_USBC1_Source = USB_C1HSEdiv2; //HSE 
	USB_Clock_InitStruct.USB_PLLUSBMUL = USB_PLLUSBMUL6;   //was 12

	USB_DeviceBUSParam.MODE = USB_SC_SCFSP_Full;
	USB_DeviceBUSParam.SPEED = USB_SC_SCFSR_12Mb;
	USB_DeviceBUSParam.PULL = USB_HSCR_DP_PULLUP_Set;

	USB_DeviceInit(&USB_Clock_InitStruct, &USB_DeviceBUSParam);

	/* Enable all USB interrupts */
	USB_SetSIM(USB_SIS_Msk);

	USB_DevicePowerOn();

	/* Enable interrupt on USB */
#ifdef USB_INT_HANDLE_REQUIRED
	NVIC_EnableIRQ(USB_IRQn);
#endif /* USB_INT_HANDLE_REQUIRED */

	USB_DEVICE_HANDLE_RESET;
}

/**
	* @brief	Example-relating data initialization
	* @param	None
	* @retval None
	*/
static void VCom_Configuration(void)
{
#ifdef USB_CDC_LINE_CODING_SUPPORTED
	LineCoding.dwDTERate = 115200;
	LineCoding.bCharFormat = 0;
	LineCoding.bParityType = 0;
	LineCoding.bDataBits = 8;
#endif /* USB_CDC_LINE_CODING_SUPPORTED */
}

/**
	* @brief	USB_CDC_HANDLE_DATA_RECEIVE implementation - data echoing
	* @param	Buffer: Pointer to the user's buffer with received data
	* @param	Length: Length of data
	* @retval @ref USB_Result.
	*/
USB_Result USB_CDC_RecieveData(uint8_t *Buffer, uint32_t Length)
{
	  //USBD_CDC_SetRxBuffer(&hUsbDeviceFS, &Buf[0]);
	//USB_CDC_SetReceiveBuffer(Buffer, 1);
  //uint8_t len = (uint8_t) Length; // Get length
  uint16_t tempHeadPos = rxBufferHeadPos; // Increment temp head pos while writing, then update main variable when complete

  for (uint32_t i = 0; i < Length; i++) {
    rxBuffer[tempHeadPos] = Buffer[i];
    tempHeadPos = (uint16_t)((uint16_t)(tempHeadPos + 1) % HL_RX_BUFFER_SIZE);
    if (tempHeadPos == rxBufferTailPos) {
      return USB_ERROR;
    }
  }

  rxBufferHeadPos = tempHeadPos;
  
	//RecBuf[Length] = 0; //wtf last byte on odd wrong.
	return USB_SUCCESS;
}

uint16_t USB_CDC_GetRxBufferBytesAvailable_FS()
{
  return (uint16_t)(rxBufferHeadPos - rxBufferTailPos) % HL_RX_BUFFER_SIZE;
}


uint8_t USB_CDC_ReadRxBuffer_FS(uint8_t* Buf, uint16_t Len)
{
  uint16_t bytesAvailable = USB_CDC_GetRxBufferBytesAvailable_FS();

  if (bytesAvailable < Len)
    return USB_CDC_RX_BUFFER_NO_DATA;

  for (uint8_t i = 0; i < Len; i++) {
    Buf[i] = rxBuffer[rxBufferTailPos];
    rxBufferTailPos = (uint16_t)((uint16_t)(rxBufferTailPos + 1) % HL_RX_BUFFER_SIZE);
  }

  return USB_CDC_RX_BUFFER_OK;
}

void USB_CDC_FlushRxBuffer_FS()
{
  //for (int i = 0; i < HL_RX_BUFFER_SIZE; i++) {
  //  rxBuffer[i] = 0;
  //}
	memset(rxBuffer, 0, HL_RX_BUFFER_SIZE);

  rxBufferHeadPos = 0;
  rxBufferTailPos = 0;
}



#ifdef USB_CDC_LINE_CODING_SUPPORTED

/**
	* @brief	USB_CDC_HANDLE_GET_LINE_CODING implementation example
	* @param	wINDEX: Request value 2nd word (wIndex)
	* @param	DATA: Pointer to the USB_CDC Line Coding Structure
	* @retval @ref USB_Result.
	*/
USB_Result USB_CDC_GetLineCoding(uint16_t wINDEX, USB_CDC_LineCoding_TypeDef *DATA)
{
	assert_param(DATA);
	if (wINDEX != 0)
	{
		/* Invalid interface */
		return USB_ERR_INV_REQ;
	}

	/* Just store received settings */
	*DATA = LineCoding;
	return USB_SUCCESS;
}

/**
	* @brief	USB_CDC_HANDLE_SET_LINE_CODING implementation example
	* @param	wINDEX: Request value 2nd word (wIndex)
	* @param	DATA: Pointer to the USB_CDC Line Coding Structure
	* @retval @ref USB_Result.
	*/
USB_Result USB_CDC_SetLineCoding(uint16_t wINDEX, const USB_CDC_LineCoding_TypeDef *DATA)
{
	assert_param(DATA);
	if (wINDEX != 0)
	{
		/* Invalid interface */
		return USB_ERR_INV_REQ;
	}

	/* Just send back settings stored earlier */
	LineCoding = *DATA;
	return USB_SUCCESS;
}

#endif /* USB_CDC_LINE_CODING_SUPPORTED */
